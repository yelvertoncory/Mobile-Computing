package com.example.coryyelverton.mc_assignment3;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DiaryInterface extends AppCompatActivity {

    Button buttonAdd;
    Button buttonView;
    EditText editSubject;
    EditText editEntry;
    DatabaseClass myDB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary_interface);

        buttonAdd = (Button)findViewById(R.id.buttonAdd);
        buttonView = (Button)findViewById(R.id.buttonView);
        editSubject = (EditText)findViewById(R.id.editTextSubject);
        editEntry = (EditText)findViewById(R.id.editTextEntry);

        myDB = new DatabaseClass(this);

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newSubject = String.valueOf(editSubject.getText());
                String newEntry = String.valueOf(editEntry.getText());
                String newDate  = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

                boolean insert = myDB.addEntry(newSubject,newEntry,newDate);
                if(insert == true){
                    Toast.makeText(DiaryInterface.this ,"TEST",Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(DiaryInterface.this ,"TST",Toast.LENGTH_LONG).show();
                }


            }
        });

        buttonView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DiaryInterface.this, Diary.class);
                startActivity(intent);
            }
        });
    }

    //public void AddData(String newSubject, String newEntry, String newDate) {

        //myDB.addData(newSubject, newEntry, newDate);


    //}
}
