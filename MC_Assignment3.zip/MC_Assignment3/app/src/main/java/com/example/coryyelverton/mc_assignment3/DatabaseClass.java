package com.example.coryyelverton.mc_assignment3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Cory Yelverton on 4/1/2018.
 */

public class DatabaseClass extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "diary.db";
    public static final String TABLE_NAME = "myDiary";
    public static final String myDiary_ID = "ID";
    public static final String myDiary_SUBJECT = "SUBJECT";
    public static final String myDIARY_ENTRY = "ENTRY";
    public static final String myDiary_DATE = "DATE";

    public DatabaseClass(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String createTable = "CREATE TABLE " + TABLE_NAME + "(ID" + " " + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "SUBJECT TEXT, ENTRY TEXT, DATE TEXT)";
        sqLiteDatabase.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(sqLiteDatabase);
    }

    public boolean addEntry(String subject, String entry, String date){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(myDiary_SUBJECT, subject );
        values.put(myDIARY_ENTRY, entry);
        values.put(myDiary_DATE,date);
         long checker = db.insert(TABLE_NAME, null, values);
        if(checker == -1){
            return false;
        }else{
            return true;
        }
    }

  public Cursor showData(){
        SQLiteDatabase myDB = this.getWritableDatabase();
        Cursor data = myDB.rawQuery("SELECT * FROM " + TABLE_NAME,null);
        return data;
  }


}
