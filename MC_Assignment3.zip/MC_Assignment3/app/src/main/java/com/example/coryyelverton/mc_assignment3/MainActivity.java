package com.example.coryyelverton.mc_assignment3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    EditText password;
    Button login;
    TextView title;
    TextView passwordTitle;
    TextView toast;
    String key;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        key = "unlock";

        password = (EditText)findViewById(R.id.editTextPassword);
        login = (Button)findViewById(R.id.buttonLogin);
        title = (TextView)findViewById(R.id.textViewTitle);
        passwordTitle=(TextView)findViewById(R.id.textViewPassword);
        toast = (TextView)findViewById(R.id.toastMessage);
        final SharedPreferences preferences = getSharedPreferences("password",Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor  = preferences.edit();
        editor.putString("password",key);
        editor.commit();
        title.setTextSize(50);
        passwordTitle.setTextSize(20);



        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                SharedPreferences preferences = getSharedPreferences("password",Context.MODE_PRIVATE);
                String attempt = String.valueOf(password.getText());
                String getKey = String.valueOf(preferences.getString("password",""));
                String newDate  = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                if(attempt.equals(getKey)) {
                    Intent diaryIntent = new Intent(view.getContext(),DiaryInterface.class);
                    startActivity(diaryIntent);
                }
                else{
                    toast.setText(newDate);
                }

            }
        });
    }
}
