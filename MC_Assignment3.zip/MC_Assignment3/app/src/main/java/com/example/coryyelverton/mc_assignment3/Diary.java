package com.example.coryyelverton.mc_assignment3;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class Diary extends AppCompatActivity {

    DatabaseClass myDB;
    TextView diary;
    Cursor data = myDB.showData();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary);

        myDB = new DatabaseClass(this);
        diary = (TextView)findViewById(R.id.textViewDiary);

        Cursor data = myDB.showData();
        if(data.getCount() == 0){
            diary.setText("No data");
        }
        StringBuffer buffer = new StringBuffer();
        while(data.moveToNext()){
            buffer.append("ID" + data.getString(0) + "/n");
            buffer.append("SUBJECT" + data.getString(1) + "/n");
            buffer.append("Entry" + data.getString(2) + "/n");
            buffer.append("DATE" + data.getString(3) + "/n");

            diary.setText(buffer.toString());
        }



    }
}
